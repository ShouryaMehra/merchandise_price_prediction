from flask import *
from flask import Flask, render_template, request

import sqlite3 #import databse sqlite3
from joblib import load ,dump

import logging
import random as r
 
# initialize logging 
LOG_FILE_NAME= 'loanApplog.txt'
logging.basicConfig(level=logging.DEBUG,
                    format='%(asctime)s %(name)-12s %(levelname)-8s %(message)s''',
                    datefmt='%m-%d %H:%M',
                    filename=LOG_FILE_NAME,
                    filemode='w')

app = Flask(__name__) #create instence of web server
conn = sqlite3.connect('User_complaintDB.db')
#*******************************  create database and create table
#conn = sqlite3.connect('User_complaintDB.db')  
#c = conn.cursor()  #  it create memory to store working data in memory and that cursor communicate with database
 
# Create table
#it contain parameters of html code. ex.- field name and type.  
#c.execute('''CREATE TABLE complaints
#             (id text, name text, invref text, invdate date, pname text, nature text)''')
#************************************

#*************************************************************************************
#joblib internel code

import pandas as pd
from sklearn.preprocessing import LabelEncoder as le
from sklearn.tree import DecisionTreeRegressor
dataframe=pd.read_csv('C:/Users/Shourya/Downloads/New folder/train.tsv', sep='\t')


#Fill nan values using fillna function 
dataframe.category_name.fillna("Women/Athletic Apparel/Pants, Tights, Leggings",inplace=True)
dataframe.brand_name.fillna("Not Available",inplace=True)
dataframe.item_description.fillna("No description yet", inplace=True)

dataframe=dataframe.drop(['shipping','item_description','train_id'], axis=1)

#apply encoding to our data
dataframe[['name','category_name','brand_name']]= dataframe[['name','category_name','brand_name']].apply(le().fit_transform)


#change data type into int
dataframe[['price']]=dataframe[['price']].astype(int)

X_train = dataframe.drop('price', axis=1)
Y_train = dataframe[['price']]

#create an instance of our model
dtr = DecisionTreeRegressor()
dtr.fit(X_train,Y_train)



# from joblib import dump, load
# dump(dtr, 'dtr.joblib')
# app = load('dtr.joblib')


#**********************************************************************************************
# dtr = load('C:/Users/Shourya/ds/DS13_ASSIGNMENT_02_SHOURYA_MEHRA/dtr.joblib')

@app.route('/',methods=['POST', 'GET']) #@app use to connect to the web page #post: send data to server and GET : receive data from server.
def application():
    status = " "
    dt=[]

    if request.method == "POST":  
        print(request.form["name"]) #viwe data on console
        print(request.form["invref"])
        print(request.form["invdate"])
        print(request.form["pname"])
        print(request.form["nature"])
        dt.append(request.form["name"])
        dt.append(request.form["invref"])
        dt.append(request.form["invdate"])
        dt.append(request.form["pname"])
        dt.append(request.form["nature"])
        #insert rows in database
        conn = sqlite3.connect('User_complaintDB.db')   #connect to database and if there is no database them it will create database
        c = conn.cursor()  #  it create memory to store working data in memory and that cursor communicate with database
        
        c.execute("SELECT * FROM complaints")
        
        def otpgen():
            otp=""
            for i in range(8):
                otp+=str(r.randint(1,9))
            return otp    
        password=otpgen()
        dt.append(password)
        dt.append("SUBMIT")
        c.execute("INSERT INTO complaints(name, invref, invdate,pname,nature,id,status) values(?,?,?,?,?,?,?)",dt)
        c.execute("COMMIT")
        status = "Complaint registered successfully and your ID is: ", password;
        c.close()
        return render_template("application.html",complaint_status=status,ref = password )
    return render_template("application.html",complaint_status=status)
        
        
@app.route('/status',methods=['POST', 'GET'])
def main():
     if request.method == "POST":  
            print(request.form["ref"])  
            resultQ = request.form["ref"]
            with sqlite3.connect('User_complaintDB.db') as con: 
                con.row_factory = sqlite3.Row
                try:  
                        
                        cur = con.cursor()  
                        cur.execute("SELECT * FROM complaints WHERE id = ?",(resultQ,))  
                        msg = cur.fetchall()
                        if len(msg) > 0:
                            return render_template("message.html",msg = msg)
                        else:
                            msg = "INVALID ID TRY AGAIN"
                            return render_template("message.html",msg = msg)
                         
                except Exception as e:
	                      return e
                    
     return render_template("status.html")        
 
@app.route('/list')
def list():
   con = sqlite3.connect("User_complaintDB.db")
   con.row_factory = sqlite3.Row
   
   cur = con.cursor()
   cur.execute("select * from complaints")
   
   rows = cur.fetchall();
   return render_template("list.html",rows = rows)

@app.route('/index')
def index():
    return render_template('index.html')

@app.route('/prd',methods=['POST','GET'])
#def home():
#    home_page = right all html code here \
def predict_price():
    name = 0
    item_condition = 0
    category_name = 0
    brand_name = 0
    price = 0
    
    if request.method == 'POST':
        name =int(request.form['name'])
        item_condition = int(request.form['item_condition'])
        category_name = int(request.form['category_name'])
        brand_name = int(request.form['brand_name']) 
        print(name,item_condition,category_name,brand_name)
        price = dtr.predict([[name,item_condition,category_name,brand_name]])
        
    return render_template('price_prediction_application.html',name=name,item_condition=item_condition,category_name=category_name,brand_name=brand_name,price = price )  


    
if __name__ == '__main__': #this only page run as a main page if it not run as a main page web server will not work,
    app.run() #run the server


    